import xbmc, xbmcaddon, xbmcgui
import xbmcvfs
import os

parent_dir = xbmcvfs.translatePath("special://home/addons")

#FEN & FORKS
fen_forks = [
    "plugin.video.fen",                 #Fen
    "plugin.video.coalition",           #Coalition
    "plugin.video.pov"                  #POV
    ]

#VENOM & FORKS
venom_forks = [
    "plugin.video.umbrella",            #Umbrella
    "plugin.video.dradis"               #Dradis
    ]

#SHADOW & FORKS
shadow_forks = [
    "plugin.video.shadow",              #Shadow
    "plugin.video.ghost",               #Ghost
    "plugin.video.base",                #Base
    "plugin.video.thechains",           #Chains
    "plugin.video.asgard",              #Asgard
    "plugin.video.patriot",             #Patriot
    "plugin.video.blacklightning",      #Black Lightning
    "plugin.video.aliundek19",          #Aliunde
    "plugin.video.NightwingLite"        #Nightwing Lite
    ]

#OATH & FORKS
oath_forks = [
    "plugin.video.homelander",          #Homelander
    "plugin.video.quicksilver",         #Quicksilver
    "plugin.video.chainsgenocide",      #Genocide
    "plugin.video.absolution",          #Absolution
    "plugin.video.shazam",              #Shazam
    "plugin.video.thecrew",             #The Crew
    "plugin.video.alvin",               #Alvin
    "plugin.video.moria",               #Moria
    "plugin.video.nine",                #Nine Lives
    "plugin.video.metv19"               #METV
    ]

#OTHER
other = [
    "plugin.video.seren",               #Seren
    "plugin.video.fenlight",            #Fen Light
    "plugin.video.otaku",               #Otaku
    "plugin.video.scrubsv2"             #Scrubs V2
]

def create_list(parent_path):
    directory_names = []
    if os.path.isdir(parent_path):
        subdirectories = [d for d in os.listdir(parent_path) if os.path.isdir(os.path.join(parent_path, d))]
        for directory_name in subdirectories:
            if 'plugin.video' in directory_name:
                directory_names.append(directory_name)  
    return directory_names
plugins = create_list(parent_dir)

def maxql():
    supported_addons = fen_forks + venom_forks + shadow_forks + oath_forks + other
    names = []
    for plugin in plugins:
        if plugin in supported_addons:
            names.append(plugin)
        else:
            print(f"Directory '{plugin}' is NOT supported by MaxQL")
    return names
addon_list = maxql()
