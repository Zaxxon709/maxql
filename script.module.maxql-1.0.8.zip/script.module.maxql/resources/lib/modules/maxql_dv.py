import xbmc, xbmcaddon, xbmcgui
import xbmcvfs
import string
import os

addon_icon = 'special://home/addons/script.module.maxql/icon.png'

def seren_enable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.seren/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.seren/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):
        chk_seren_ftr = xbmcaddon.Addon('plugin.video.seren').getSetting("general.filters")
        addon = xbmcaddon.Addon("plugin.video.seren")
        setting = addon.getSetting("general.filters")
        single_ftr = 'DV'
        additional_ftr = ',DV'
        
        if str(chk_seren_ftr) != '' and single_ftr not in str(chk_seren_ftr):
            addon.setSetting("general.filters", setting + additional_ftr)
            
        else:
            addon.setSetting("general.filters", single_ftr)        

def seren_disable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.seren/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.seren/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):
        chk_seren_ftr = xbmcaddon.Addon('plugin.video.seren').getSetting("general.filters")
        addon = xbmcaddon.Addon("plugin.video.seren")
        setting = addon.getSetting("general.filters")
        single_ftr = 'DV'
        additional_ftr1 = ',DV'
        additional_ftr2 = 'DV,'
        
        if str(chk_seren_ftr) == single_ftr:
            addon.setSetting("general.filters", "AV1")
            
        if additional_ftr1 in chk_seren_ftr:
            current = str(addon.getSetting("general.filters"))
            new = current.replace(",DV", "")
            addon.setSetting("general.filters", new)
            
        if additional_ftr2 in chk_seren_ftr:
            current = str(addon.getSetting("general.filters"))
            new = current.replace("DV,", "")
            addon.setSetting("general.filters", new)
            
def fen_enable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.fen/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.fen/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        ftr = '0'
        addon = xbmcaddon.Addon("plugin.video.fen")
        addon.setSetting("filter_dv", ftr)

def fen_disable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.fen/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.fen/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        ftr = '1'
        addon = xbmcaddon.Addon("plugin.video.fen")
        addon.setSetting("filter_dv", ftr)

def pov_enable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.pov/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.pov/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        ftr = '0'
        addon = xbmcaddon.Addon("plugin.video.pov")
        addon.setSetting("filter_dv", ftr)

def pov_disable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.pov/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.pov/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        ftr = '1'
        addon = xbmcaddon.Addon("plugin.video.pov")
        addon.setSetting("filter_dv", ftr)

def coalition_enable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.coalition/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.coalition/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        ftr = '0'
        addon = xbmcaddon.Addon("plugin.video.coalition")
        addon.setSetting("filter_dv", ftr)

def coalition_disable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.coalition/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.coalition/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        ftr = '1'
        addon = xbmcaddon.Addon("plugin.video.coalition")
        addon.setSetting("filter_dv", ftr)

def ezra_enable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.ezra/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.ezra/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        ftr = '0'
        addon = xbmcaddon.Addon("plugin.video.ezra")
        addon.setSetting("filter_dv", ftr)


def ezra_disable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.ezra/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.ezra/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        ftr = '1'
        addon = xbmcaddon.Addon("plugin.video.ezra")
        addon.setSetting("filter_dv", ftr)

def umbrella_enable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.umbrella/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.umbrella/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        ftr = 'false'
        addon = xbmcaddon.Addon("plugin.video.umbrella")
        addon.setSetting("remove.dolby.vision", ftr)

def umbrella_disable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.umbrella/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.umbrella/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        ftr = 'true'
        addon = xbmcaddon.Addon("plugin.video.umbrella")
        addon.setSetting("remove.dolby.vision", ftr)
	
def homelander_enable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.homelander/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.homelander/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        ftr = 'false'
        addon = xbmcaddon.Addon("plugin.video.homelander")
        addon.setSetting("remove.dv", ftr)

def homelander_disable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.homelander/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.homelander/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        ftr = 'true'
        addon = xbmcaddon.Addon("plugin.video.homelander")
        addon.setSetting("remove.dv", ftr)

def nightwing_enable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.nightwing/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.nightwing/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        ftr = 'false'
        addon = xbmcaddon.Addon("plugin.video.nightwing")
        addon.setSetting("remove.dv", ftr)

def nightwing_disable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.nightwing/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.nightwing/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        ftr = 'true'
        addon = xbmcaddon.Addon("plugin.video.nightwing")
        addon.setSetting("remove.dv", ftr)

def moria_enable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.moria/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.moria/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        ftr = 'false'
        addon = xbmcaddon.Addon("plugin.video.moria")
        addon.setSetting("remove.dv", ftr)

def moria_disable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.moria/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.moria/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        ftr = 'true'
        addon = xbmcaddon.Addon("plugin.video.moria")
        addon.setSetting("remove.dv", ftr)

def absolution_enable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.absolution/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.absolution/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        ftr = 'false'
        addon = xbmcaddon.Addon("plugin.video.absolution")
        addon.setSetting("remove.dv", ftr)

def absolution_disable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.absolution/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.absolution/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        ftr = 'true'
        addon = xbmcaddon.Addon("plugin.video.absolution")
        addon.setSetting("remove.dv", ftr)

def shazam_enable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.shazam/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.shazam/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        ftr = 'false'
        addon = xbmcaddon.Addon("plugin.video.shazam")
        addon.setSetting("remove.dv", ftr)

def shazam_disable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.shazam/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.shazam/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        ftr = 'true'
        addon = xbmcaddon.Addon("plugin.video.shazam")
        addon.setSetting("remove.dv", ftr)

def alvin_enable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.alvin/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.alvin/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        ftr = 'false'
        addon = xbmcaddon.Addon("plugin.video.alvin")
        addon.setSetting("remove.dv", ftr)

def alvin_disable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.alvin/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.alvin/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        ftr = 'true'
        addon = xbmcaddon.Addon("plugin.video.alvin")
        addon.setSetting("remove.dv", ftr)

def genocide_enable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.chainsgenocide/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.chainsgenocide/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        ftr = 'false'
        addon = xbmcaddon.Addon("plugin.video.chainsgenocide")
        addon.setSetting("remove.dv", ftr)

def genocide_disable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.chainsgenocide/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.chainsgenocide/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        ftr = 'true'
        addon = xbmcaddon.Addon("plugin.video.chainsgenocide")
        addon.setSetting("remove.dv", ftr)

def quicksilver_enable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.quicksilver/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.quicksilver/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        ftr = 'false'
        addon = xbmcaddon.Addon("plugin.video.quicksilver")
        addon.setSetting("remove.dv", ftr)

def quicksilver_disable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.quicksilver/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.quicksilver/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        ftr = 'true'
        addon = xbmcaddon.Addon("plugin.video.quicksilver")
        addon.setSetting("remove.dv", ftr)

def ninelives_enable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.nine/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.nine/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        ftr = 'false'
        addon = xbmcaddon.Addon("plugin.video.nine")
        addon.setSetting("remove.dv", ftr)
        
def ninelives_disable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.nine/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.nine/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        ftr = 'true'
        addon = xbmcaddon.Addon("plugin.video.nine")
        addon.setSetting("remove.dv", ftr)
        
def enable_dv():
        seren_enable()
        fen_enable()
        pov_enable()
        coalition_enable()
        ezra_enable()
        umbrella_enable()
        homelander_enable()
        nightwing_enable()
        moria_enable()
        absolution_enable()
        shazam_enable()
        alvin_enable()
        genocide_enable()
        quicksilver_enable()
        ninelives_enable()
        xbmc.executebuiltin('Action(back)')
        xbmcgui.Dialog().notification('MaxQL', 'Dolby Vision Enabled!', addon_icon, 3000)

def disable_dv():
        seren_disable()
        fen_disable()
        pov_disable()
        coalition_disable()
        ezra_disable()
        umbrella_disable()
        homelander_disable()
        nightwing_disable()
        moria_disable()
        absolution_disable()
        shazam_disable()
        alvin_disable()
        genocide_disable()
        quicksilver_disable()
        ninelives_disable()
        xbmc.executebuiltin('Action(back)')
        xbmcgui.Dialog().notification('MaxQL', 'Dolby Vision Disabled!', addon_icon, 3000)
exit
