import xbmc, xbmcaddon, xbmcgui
import xbmcvfs
import string
import os

addon_icon = 'special://home/addons/script.module.maxql/icon.png'

def seren_enable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.seren/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.seren/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):
        chk_seren_ftr = xbmcaddon.Addon('plugin.video.seren').getSetting("general.filters")
        addon = xbmcaddon.Addon("plugin.video.seren")
        setting = addon.getSetting("general.filters")
        single_ftr = '3D'
        additional_ftr = ',3D'
        
        if str(chk_seren_ftr) != '' and single_ftr not in str(chk_seren_ftr):
            addon.setSetting("general.filters", setting + additional_ftr)
            
        else:
            addon.setSetting("general.filters", single_ftr)        

def seren_disable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.seren/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.seren/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):
        chk_seren_ftr = xbmcaddon.Addon('plugin.video.seren').getSetting("general.filters")
        addon = xbmcaddon.Addon("plugin.video.seren")
        setting = addon.getSetting("general.filters")
        single_ftr = '3D'
        additional_ftr1 = ',3D'
        additional_ftr2 = '3D,'
        
        if str(chk_seren_ftr) == '3D':
            addon.setSetting("general.filters", "AV1")

        if additional_ftr1 in chk_seren_ftr:
            current = str(addon.getSetting("general.filters"))
            new = current.replace(",3D", "")
            addon.setSetting("general.filters", new)
            
        if additional_ftr2 in chk_seren_ftr:
            current = str(addon.getSetting("general.filters"))
            new = current.replace("3D,", "")
            addon.setSetting("general.filters", new)
            
def fen_enable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.fen/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.fen/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        ftr = 'true'
        addon = xbmcaddon.Addon("plugin.video.fen")
        addon.setSetting("include_3d_results", ftr)

def fen_disable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.fen/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.fen/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        ftr = 'false'
        addon = xbmcaddon.Addon("plugin.video.fen")
        addon.setSetting("include_3d_results", ftr)

def pov_enable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.pov/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.pov/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        ftr = 'true'
        addon = xbmcaddon.Addon("plugin.video.pov")
        addon.setSetting("include_3d_results", ftr)

def pov_disable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.pov/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.pov/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        ftr = 'false'
        addon = xbmcaddon.Addon("plugin.video.pov")
        addon.setSetting("include_3d_results", ftr)

def coalition_enable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.coalition/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.coalition/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        ftr = 'true'
        addon = xbmcaddon.Addon("plugin.video.coalition")
        addon.setSetting("include_3d_results", ftr)

def coalition_disable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.coalition/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.coalition/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        ftr = 'false'
        addon = xbmcaddon.Addon("plugin.video.coalition")
        addon.setSetting("include_3d_results", ftr)

def ezra_enable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.ezra/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.ezra/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        ftr = 'true'
        addon = xbmcaddon.Addon("plugin.video.ezra")
        addon.setSetting("include_3d_results", ftr)


def ezra_disable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.ezra/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.ezra/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        ftr = 'false'
        addon = xbmcaddon.Addon("plugin.video.ezra")
        addon.setSetting("include_3d_results", ftr)

def umbrella_enable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.umbrella/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.umbrella/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        ftr = 'false'
        addon = xbmcaddon.Addon("plugin.video.umbrella")
        addon.setSetting("remove.3D.sources", ftr)

def umbrella_disable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.umbrella/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.umbrella/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        ftr = 'true'
        addon = xbmcaddon.Addon("plugin.video.umbrella")
        addon.setSetting("remove.3D.sources", ftr)
        
def ghost_enable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.ghost/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.ghost/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        encoding = 'true'
        ftr = 'true'
        addon = xbmcaddon.Addon("plugin.video.ghost")
        addon.setSetting("encoding_filter", encoding)
        addon.setSetting("3d", ftr)
        addon.setSetting("encoding_filter_tv", encoding)
        addon.setSetting("3d_tv", ftr)

def ghost_disable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.ghost/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.ghost/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        encoding = 'false'
        ftr = 'false'
        addon = xbmcaddon.Addon("plugin.video.ghost")
        addon.setSetting("encoding_filter", encoding)
        addon.setSetting("3d", ftr)
        addon.setSetting("encoding_filter_tv", encoding)
        addon.setSetting("3d_tv", ftr)

def shadow_enable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.shadow/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.shadow/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        encoding = 'true'
        ftr = 'true'
        addon = xbmcaddon.Addon("plugin.video.shadow")
        addon.setSetting("encoding_filter", encoding)
        addon.setSetting("3d", ftr)
        addon.setSetting("encoding_filter_tv", encoding)
        addon.setSetting("3d_tv", ftr)

def shadow_disable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.shadow/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.shadow/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        encoding = 'false'
        ftr = 'false'
        addon = xbmcaddon.Addon("plugin.video.shadow")
        addon.setSetting("encoding_filter", encoding)
        addon.setSetting("3d", ftr)
        addon.setSetting("encoding_filter_tv", encoding)
        addon.setSetting("3d_tv", ftr)
	
def thechains_enable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.thechains/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.thechains/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        encoding = 'true'
        ftr = 'true'
        addon = xbmcaddon.Addon("plugin.video.thechains")
        addon.setSetting("encoding_filter", encoding)
        addon.setSetting("3d", ftr)
        addon.setSetting("encoding_filter_tv", encoding)
        addon.setSetting("3d_tv", ftr)

def thechains_disable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.thechains/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.thechains/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        encoding = 'false'
        ftr = 'false'
        addon = xbmcaddon.Addon("plugin.video.thechains")
        addon.setSetting("encoding_filter", encoding)
        addon.setSetting("3d", ftr)
        addon.setSetting("encoding_filter_tv", encoding)
        addon.setSetting("3d_tv", ftr)
	
def unleashed_enable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.unleashed/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.unleashed/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        encoding = 'true'
        ftr = 'true'
        addon = xbmcaddon.Addon("plugin.video.unleashed")
        addon.setSetting("encoding_filter", encoding)
        addon.setSetting("3d", ftr)
        addon.setSetting("encoding_filter_tv", encoding)
        addon.setSetting("3d_tv", ftr)

def unleashed_disable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.unleashed/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.unleashed/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        encoding = 'false'
        ftr = 'false'
        addon = xbmcaddon.Addon("plugin.video.unleashed")
        addon.setSetting("encoding_filter", encoding)
        addon.setSetting("3d", ftr)
        addon.setSetting("encoding_filter_tv", encoding)
        addon.setSetting("3d_tv", ftr)
	
def base19_enable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.base19/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.base19/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        encoding = 'true'
        ftr = 'true'
        addon = xbmcaddon.Addon("plugin.video.base19")
        addon.setSetting("encoding_filter", encoding)
        addon.setSetting("3d", ftr)
        addon.setSetting("encoding_filter_tv", encoding)
        addon.setSetting("3d_tv", ftr)

def base19_disable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.base19/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.base19/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        encoding = 'false'
        ftr = 'false'
        addon = xbmcaddon.Addon("plugin.video.base19")
        addon.setSetting("encoding_filter", encoding)
        addon.setSetting("3d", ftr)
        addon.setSetting("encoding_filter_tv", encoding)
        addon.setSetting("3d_tv", ftr)
	
def metv19_enable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.metv19/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.metv19/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        encoding = 'true'
        ftr = 'true'
        addon = xbmcaddon.Addon("plugin.video.metv19")
        addon.setSetting("encoding_filter", encoding)
        addon.setSetting("3d", ftr)
        addon.setSetting("encoding_filter_tv", encoding)
        addon.setSetting("3d_tv", ftr)

def metv19_disable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.metv19/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.metv19/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        encoding = 'false'
        ftr = 'false'
        addon = xbmcaddon.Addon("plugin.video.metv19")
        addon.setSetting("encoding_filter", encoding)
        addon.setSetting("3d", ftr)
        addon.setSetting("encoding_filter_tv", encoding)
        addon.setSetting("3d_tv", ftr)
	
def asgard_enable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.asgard/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.asgard/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        encoding = 'true'
        ftr = 'true'
        addon = xbmcaddon.Addon("plugin.video.asgard")
        addon.setSetting("encoding_filter", encoding)
        addon.setSetting("3d", ftr)
        addon.setSetting("encoding_filter_tv", encoding)
        addon.setSetting("3d_tv", ftr)

def asgard_disable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.asgard/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.asgard/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        encoding = 'false'
        ftr = 'false'
        addon = xbmcaddon.Addon("plugin.video.asgard")
        addon.setSetting("encoding_filter", encoding)
        addon.setSetting("3d", ftr)
        addon.setSetting("encoding_filter_tv", encoding)
        addon.setSetting("3d_tv", ftr)

def magicdragon_enable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.magicdragon/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.magicdragon/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        encoding = 'true'
        ftr = 'true'
        addon = xbmcaddon.Addon("plugin.video.magicdragon")
        addon.setSetting("encoding_filter", encoding)
        addon.setSetting("3d", ftr)
        addon.setSetting("encoding_filter_tv", encoding)
        addon.setSetting("3d_tv", ftr)

def magicdragon_disable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.magicdragon/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.magicdragon/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        encoding = 'false'
        ftr = 'false'
        addon = xbmcaddon.Addon("plugin.video.magicdragon")
        addon.setSetting("encoding_filter", encoding)
        addon.setSetting("3d", ftr)
        addon.setSetting("encoding_filter_tv", encoding)
        addon.setSetting("3d_tv", ftr)
	
def aliunde_enable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.aliundek19/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.aliundek19/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        encoding = 'true'
        ftr = 'true'
        addon = xbmcaddon.Addon("plugin.video.aliundek19")
        addon.setSetting("encoding_filter", encoding)
        addon.setSetting("3d", ftr)
        addon.setSetting("encoding_filter_tv", encoding)
        addon.setSetting("3d_tv", ftr)

def aliunde_disable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.aliundek19/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.aliundek19/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        encoding = 'false'
        ftr = 'false'
        addon = xbmcaddon.Addon("plugin.video.aliundek19")
        addon.setSetting("encoding_filter", encoding)
        addon.setSetting("3d", ftr)
        addon.setSetting("encoding_filter_tv", encoding)
        addon.setSetting("3d_tv", ftr)

def patriot_enable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.patriot/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.patriot/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        encoding = 'true'
        ftr = 'true'
        addon = xbmcaddon.Addon("plugin.video.patriot")
        addon.setSetting("encoding_filter", encoding)
        addon.setSetting("3d", ftr)
        addon.setSetting("encoding_filter_tv", encoding)
        addon.setSetting("3d_tv", ftr)

def patriot_disable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.patriot/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.patriot/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        encoding = 'false'
        ftr = 'false'
        addon = xbmcaddon.Addon("plugin.video.patriot")
        addon.setSetting("encoding_filter", encoding)
        addon.setSetting("3d", ftr)
        addon.setSetting("encoding_filter_tv", encoding)
        addon.setSetting("3d_tv", ftr)

def bl_enable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.blacklightning/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.blacklightning/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        encoding = 'true'
        ftr = 'true'
        addon = xbmcaddon.Addon("plugin.video.blacklightning")
        addon.setSetting("encoding_filter", encoding)
        addon.setSetting("3d", ftr)
        addon.setSetting("encoding_filter_tv", encoding)
        addon.setSetting("3d_tv", ftr)

def bl_disable():
    addon = xbmcvfs.translatePath('special://home/addons/plugin.video.blacklightning/')
    file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.blacklightning/settings.xml')

    if xbmcvfs.exists(addon) and xbmcvfs.exists(file):

        encoding = 'false'
        ftr = 'false'
        addon = xbmcaddon.Addon("plugin.video.blacklightning")
        addon.setSetting("encoding_filter", encoding)
        addon.setSetting("3d", ftr)
        addon.setSetting("encoding_filter_tv", encoding)
        addon.setSetting("3d_tv", ftr)
        
def enable_3d():
        seren_enable()
        fen_enable()
        pov_enable()
        coalition_enable()
        ezra_enable()
        umbrella_enable()
        ghost_enable()
        shadow_enable()
        thechains_enable()
        unleashed_enable()
        base19_enable()
        metv19_enable()
        asgard_enable()
        magicdragon_enable()
        aliunde_enable()
        patriot_enable()
        bl_enable()
        xbmc.executebuiltin('Action(back)')
        xbmcgui.Dialog().notification('MaxQL', '3D Enabled!', addon_icon, 3000)

def disable_3d():
        seren_disable()
        fen_disable()
        pov_disable()
        coalition_disable()
        ezra_disable()
        umbrella_disable()
        ghost_disable()
        shadow_disable()
        thechains_disable()
        unleashed_disable()
        base19_disable()
        metv19_disable()
        asgard_disable()
        magicdragon_disable()
        aliunde_disable()
        patriot_disable()
        bl_disable()
        xbmc.executebuiltin('Action(back)')
        xbmcgui.Dialog().notification('MaxQL', '3D Disabled!', addon_icon, 3000)
exit
