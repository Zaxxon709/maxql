import xbmc, xbmcaddon, xbmcgui
import xbmcvfs
import os

#FEN & FORKS
fen_forks = [
    {"name": "Fen", "path": "special://home/addons/plugin.video.fen/"},
    {"name": "Coalition", "path": "special://home/addons/plugin.video.coalition/"},
    {"name": "POV", "path": "special://home/addons/plugin.video.pov/"}
    ]

#VENOM & FORKS
venom_forks = [
    {"name": "Umbrella", "path": "special://home/addons/plugin.video.umbrella/"},
    {"name": "Dradis", "path": "special://home/addons/plugin.video.dradis/"}
    ]

#SHADOW & FORKS
shadow_forks = [
    {"name": "Shadow", "path": "special://home/addons/plugin.video.shadow/"},
    {"name": "Ghost", "path": "special://home/addons/plugin.video.ghost/"},
    {"name": "Base", "path": "special://home/addons/plugin.video.base/"},
    {"name": "Chains", "path": "special://home/addons/plugin.video.thechains/"},
    {"name": "Asgard", "path": "special://home/addons/plugin.video.asgard/"},
    {"name": "Patriot", "path": "special://home/addons/plugin.video.patriot/"},
    {"name": "Black Lightening", "path": "special://home/addons/plugin.video.blacklightning/"},
    {"name": "Aliunde", "path": "special://home/addons/plugin.video.aliundek19/"},
    {"name": "Nightwing Lite", "path": "special://home/addons/plugin.video.NightwingLite/"}
    ]

#OATH & FORKS
oath_forks = [
    {"name": "Homelander", "path": "special://home/addons/plugin.video.homelander/"},
    {"name": "Quicksilver", "path": "special://home/addons/plugin.video.quicksilver/"},
    {"name": "Genocide", "path": "special://home/addons/plugin.video.chainsgenocide/"},
    {"name": "Ansolution", "path": "special://home/addons/plugin.video.absolution/"},
    {"name": "Shazam", "path": "special://home/addons/plugin.video.shazam/"},
    {"name": "The Crew", "path": "special://home/addons/plugin.video.thecrew/"},
    {"name": "Alvin", "path": "special://home/addons/plugin.video.alvin/"},
    {"name": "Moria", "path": "special://home/addons/plugin.video.moria/"},
    {"name": "Nine Lives", "path": "special://home/addons/plugin.video.nine/"},
    {"name": "Ghost", "path": "special://home/addons/plugin.video.metv19/"}
    ]

#OTHER
other = [
    {"name": "Seren", "path": "special://home/addons/plugin.video.seren/"},
    {"name": "Fen Light", "path": "special://home/addons/plugin.video.fenlight/"},
    {"name": "Scrubs", "path": "special://home/addons/plugin.video.scrubsv2/"}
]
        
def check_dirs(data_list, path_key):
    results = []
    for item in data_list:
        if path_key in item:
            name = item["name"]
            directory_path = item[path_key]
            exists = os.path.isdir(xbmcvfs.translatePath(directory_path))
            results.append((name, directory_path, exists))
        else:
            results.append((f"Key '{path_key}' not found in a dictionary.", False))
    return results

def maxql():
    addons = fen_forks + venom_forks + shadow_forks + oath_forks + other
    paths = check_dirs(addons, "path")

    names = []
    for name, path, exists in paths:
        if exists:
            items = {"name": name, "path": path}
            names.append(items)
        else:
            print(f"Directory '{path}' does NOT exist or key is missing.")
    return names
addon_names = maxql()
